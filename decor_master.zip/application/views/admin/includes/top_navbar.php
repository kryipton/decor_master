<div id="Header">
    <div id="HLogo">
        <div id="logo-area">
            <img src="<?php echo base_url("public/admin/img/preview.webp")?>" style="object-fit: contain">
        </div>
    </div>
    <div id="h-nav-icon">
        <i class="fas fa-bars" id="click"></i>
    </div>
    <div id="h-nav-right">
        <a href="<?php echo base_url("Panel_admin_page_profile_update")?>">
            <div class="hnav-r-1">
                <i class="fas fa-user-circle"></i>
                <span>Hesabım</span>
            </div>
        </a>
        <a href="<?php echo base_url("Admin/logout")?>">
            <div class="hnav-r-2">
                <i class="fas fa-sign-out-alt"></i>
                <span>Çıxış</span>
            </div>
        </a>
    </div>
</div>