<!DOCTYPE html>
<html>
<head>

    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-language" content="az">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Competible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <script src="https://kit.fontawesome.com/0b2826f6dd.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" type="text/css" href="<?php echo base_url("")?>/public/admin/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url("")?>/public/admin/css/bootstrap4-toggle.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url("")?>/public/admin/data_table/dataTables.bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url("")?>/public/admin/css/dropzone.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url("")?>/public/admin/css/iziToast.min.css">


    <link rel="stylesheet" type="text/css" href="<?php echo base_url("")?>/public/admin/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url("")?>/public/admin/css/custom.css">

    <!--    text editorun isdemesi ucun lazi olan kodlar bunlar yuxarida qalmalidir-->
    <script src="<?php echo base_url("public/admin/ckeditor/ckeditor.js")?>"></script>
    <!--    text editorun isdemesi ucun lazi olan kodlar bunlar yuxarida qalmalidir-->

    <title>Admin Panel</title>

</head>
<body>