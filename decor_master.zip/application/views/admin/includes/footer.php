</div>


</div>

</body>

<script src="<?php echo base_url()?>/public/admin/js/jquery.min.js"></script>
<script src="<?php echo base_url()?>/public/admin/js/popper.min.js"></script>
<script src="<?php echo base_url()?>/public/admin/js/bootstrap.min.js"></script>
<script src="<?php echo base_url()?>/public/admin/js/bootstrap4-toggle.min.js"></script>
<script src="<?php echo base_url()?>/public/admin/data_table/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>/public/admin/data_table/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>/public/admin/js/script.js"></script>


<script src="<?php echo base_url()?>/public/admin/js/dropzone.js"></script>
<script src="<?php echo base_url()?>/public/admin/js/iziToast.min.js"></script>
<script src="<?php echo base_url()?>/public/admin/js/sweetalert.min.js"></script>


<script type="text/javascript" src="<?php echo base_url()?>/public/admin/js/custom.js"></script>

</html>