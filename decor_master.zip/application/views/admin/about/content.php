<div id="table-area">

    <!--cedvelin adi-->
    <div id="menu-head">
        <span><?php echo $table_name_in_azeri?></span>
    </div>
    <!--cedvelin adi-->


    <!--sag teref-->
    <div class="c_overflow_auto">

        <br>
        <div class="c_update_row_div">
            <form style="text-align: left" data-action="<?php echo $update_link?>" id="c_update_form" action="<?php echo $update_link?>" method="post" enctype="multipart/form-data">
                <?php echo $update_view;?>
            </form>
        </div>
        <br><br><br>

    </div>
    <!--sag teref-->
</div>




