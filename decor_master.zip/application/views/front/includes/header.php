<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>B A U E N</title>
    <link rel="shortcut icon" href="<?=base_url("public/front/")?>img/favicon.png" />
    <link rel="stylesheet" href="<?=base_url("public/front/")?>css/plugins.css" />
    <link rel="stylesheet" href="<?=base_url("public/front/")?>css/style.css" />
</head>
