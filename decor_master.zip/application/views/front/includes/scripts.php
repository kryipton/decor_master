<!-- jQuery -->
<?php $lang = $this->session->userdata("lang")?>

<script type="text/javascript">
    var baseUrl = "<?php echo base_url(); ?>";
    var lang = "<?php echo $lang ?>";

</script>

<script src="<?=base_url("public/front/")?>js/jquery-3.5.1.min.js"></script>
<script src="<?=base_url("public/front/")?>js/jquery-migrate-3.0.0.min.js"></script>
<script src="<?=base_url("public/front/")?>js/modernizr-2.6.2.min.js"></script>
<script src="<?=base_url("public/front/")?>js/pace.js"></script>
<script src="<?=base_url("public/front/")?>js/popper.min.js"></script>
<script src="<?=base_url("public/front/")?>js/bootstrap.min.js"></script>
<script src="<?=base_url("public/front/")?>js/scrollIt.min.js"></script>
<script src="<?=base_url("public/front/")?>js/jquery.waypoints.min.js"></script>
<script src="<?=base_url("public/front/")?>js/owl.carousel.min.js"></script>
<script src="<?=base_url("public/front/")?>js/jquery.stellar.min.js"></script>
<script src="<?=base_url("public/front/")?>js/jquery.magnific-popup.js"></script>
<script src="<?=base_url("public/front/")?>js/YouTubePopUp.js"></script>
<script src="<?=base_url("public/front/")?>js/custom.js"></script>
<script src="<?=base_url("public/front/")?>js/contact.js"></script>
</body>
</html>