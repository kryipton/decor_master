<?php $this->load->view("front/includes/header")?>

<?php $this->load->view("front/includes/loader")?>

<?php $this->load->view("front/includes/navbar")?>

<?php $this->load->view("front/$page")?>

<?php $this->load->view("front/includes/footer")?>

<?php $this->load->view("front/includes/scripts")?>