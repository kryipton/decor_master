<?php

function pr($data){
    print_r("<pre>");
    print_r($data);
    die();
}
